# 📱 Guide d'installation — XAU/USD App (PWA)

## Ce que tu as besoin
- Un compte GitHub (gratuit) : https://github.com
- Ton téléphone Android ou iPhone

---

## ÉTAPE 1 — Créer un compte GitHub (si tu n'en as pas)
1. Va sur https://github.com/signup
2. Crée un compte gratuit (email + mot de passe)

---

## ÉTAPE 2 — Créer un nouveau dépôt
1. Connecte-toi sur GitHub
2. Clique sur le bouton vert **"New"** (ou + en haut à droite → New repository)
3. Nom du dépôt : **xauusd-app** (important, en minuscules)
4. Coche **"Public"**
5. Clique **"Create repository"**

---

## ÉTAPE 3 — Uploader les fichiers
Dans ton nouveau dépôt, clique **"uploading an existing file"**

Upload ces fichiers dans cet ordre :
- `index.html`
- `manifest.json`
- `sw.js`

Puis crée le dossier icons :
- Clique **"Add file" → "Create new file"**
- Tape : `icons/icon-192.png` (ça crée le dossier)
- Upload ensuite `icon-192.png` et `icon-512.png` dans le dossier icons

Clique **"Commit changes"** à chaque fois.

---

## ÉTAPE 4 — Activer GitHub Pages
1. Dans ton dépôt, va dans **Settings** (onglet en haut)
2. Dans le menu gauche, clique **"Pages"**
3. Sous "Branch", sélectionne **"main"** puis **/root**
4. Clique **"Save"**
5. Attends 1-2 minutes

Ton app sera accessible à :
**https://TON-USERNAME.github.io/xauusd-app/**

---

## ÉTAPE 5 — Installer sur ton téléphone

### Android (Chrome) :
1. Ouvre l'URL ci-dessus dans Chrome
2. Une bannière "Installer l'appli" apparaît automatiquement
3. Sinon : menu ⋮ → **"Ajouter à l'écran d'accueil"**
4. Confirme → L'icône XAU apparaît sur ton écran !

### iPhone (Safari) :
1. Ouvre l'URL dans Safari
2. Appuie sur le bouton **Partager** (carré avec flèche)
3. Fais défiler → **"Sur l'écran d'accueil"**
4. Confirme

---

## ✅ Résultat
- L'app s'ouvre en plein écran sans barre de navigateur
- Fonctionne hors-ligne (calendrier et analyse)
- L'assistant IA nécessite une connexion internet
- Icône XAU/USD sur ton écran d'accueil

---

## 🔄 Mettre à jour l'app
Pour modifier l'app, il suffit de remplacer les fichiers sur GitHub.
Les changements sont visibles après quelques minutes.
